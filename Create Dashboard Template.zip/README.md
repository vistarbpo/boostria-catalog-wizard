
  # Create Dashboard Template

  This is a code bundle for Create Dashboard Template. The original project is available at https://www.figma.com/design/pDqN9jQjH3KjhcQwcxH2X7/Create-Dashboard-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  